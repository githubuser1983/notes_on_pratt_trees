Root-Label Fields on Pratt Forests, Version 0.3
Revised application-first edition, August 6, 2026.

Compile with:
  pdflatex Root_Label_Fields_on_Pratt_Forests_v0.3.tex
  pdflatex Root_Label_Fields_on_Pratt_Forests_v0.3.tex

The manuscript uses standard TeX Live packages and is intended for pdfLaTeX.
