#!/usr/bin/env python3
"""Finite computational verification suite for
Root-Label Fields on Pratt Forests, Version 0.3.

The checks provide exact finite validation or numerical diagnostics. They do not
replace the proofs of universal statements.
"""
from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache, reduce
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

import mpmath as mp
import networkx as nx
import numpy as np
import pandas as pd
import scipy
import sympy as sp
from sympy import Matrix, Poly, Symbol, factorint, primerange
from sympy.combinatorics import Permutation, PermutationGroup

X = sp.Symbol("X")
T = sp.Symbol("T")

# Conservative bounds chosen so the complete suite is reproducible in minutes.
N_ARITH = 500
N_PAIR = 70
P_MAX = 127
N_FRONT = 60
TREE_MAX_VERTICES = 7
MONODROMY_PRIMES = [5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43]
RNG = random.Random(20260806)


def valuation(n: int, p: int) -> int:
    e = 0
    while n % p == 0:
        n //= p
        e += 1
    return e


def omega(n: int) -> int:
    return sum(factorint(n).values())


def liouville(n: int) -> int:
    return -1 if omega(n) % 2 else 1


def mobius(n: int) -> int:
    return int(sp.mobius(n))


@lru_cache(None)
def primes_upto(n: int) -> Tuple[int, ...]:
    return tuple(primerange(2, n + 1))


@lru_cache(None)
def pratt_coord_prime(p: int) -> Tuple[Tuple[int, int], ...]:
    d: Counter[int] = Counter({p: 1})
    if p > 2:
        for q, e in factorint(p - 1).items():
            for r, c in dict(pratt_coord_prime(int(q))).items():
                d[int(r)] += int(e) * int(c)
    return tuple(sorted(d.items()))


def pratt_coord(n: int) -> Dict[int, int]:
    d: Counter[int] = Counter()
    for p, e in factorint(n).items():
        for q, c in dict(pratt_coord_prime(int(p))).items():
            d[int(q)] += int(e) * int(c)
    return dict(d)


@lru_cache(None)
def f_prime(p: int) -> sp.Expr:
    if p == 2:
        return X
    prod = sp.Integer(1)
    for q, e in factorint(p - 1).items():
        prod *= f_prime(int(q)) ** int(e)
    return sp.expand(1 + prod)


def f_n(n: int) -> sp.Expr:
    prod = sp.Integer(1)
    for p, e in factorint(n).items():
        prod *= f_prime(int(p)) ** int(e)
    return sp.expand(prod)


@dataclass(frozen=True)
class LNode:
    label: int
    children: Tuple["LNode", ...] = ()


@lru_cache(None)
def pratt_tree(p: int) -> LNode:
    if p == 2:
        return LNode(2, ())
    ch: List[LNode] = []
    for q, e in sorted(factorint(p - 1).items()):
        ch.extend([pratt_tree(int(q))] * int(e))
    return LNode(p, tuple(ch))


def labeled_tree_paths(node: LNode, prefix: Tuple[int, ...] = ()) -> Dict[Tuple[int, ...], int]:
    out = {prefix: node.label}
    for i, child in enumerate(node.children):
        out.update(labeled_tree_paths(child, prefix + (i,)))
    return out


@lru_cache(None)
def front_label_counts_tree(p: int) -> Tuple[Tuple[Tuple[int, int], ...], ...]:
    node = pratt_tree(p)

    def rec(v: LNode) -> List[Counter[int]]:
        if not v.children:
            return [Counter({v.label: 1})]
        out = [Counter({v.label: 1})]
        child_lists = [rec(c) for c in v.children]
        for choice in itertools.product(*child_lists):
            s: Counter[int] = Counter()
            for c in choice:
                s.update(c)
            out.append(s)
        return out

    return tuple(tuple(sorted(c.items())) for c in rec(node))


def front_root_label_counts(n: int) -> List[Counter[Tuple[int, int]]]:
    blocks: List[Tuple[int, List[Counter[Tuple[int, int]]]]] = []
    for p, e in sorted(factorint(n).items()):
        local = []
        for fc in front_label_counts_tree(int(p)):
            local.append(Counter({(int(p), int(q)): int(c) for q, c in fc}))
        for _ in range(int(e)):
            blocks.append((int(p), local))
    if not blocks:
        return [Counter()]
    out: List[Counter[Tuple[int, int]]] = []
    for choice in itertools.product(*(b[1] for b in blocks)):
        c: Counter[Tuple[int, int]] = Counter()
        for part in choice:
            c.update(part)
        out.append(c)
    return out


def phi_prime(p: int, symbol_map: Mapping[int, sp.Symbol] | None = None) -> sp.Expr:
    support = dict(pratt_coord_prime(p)).keys()
    if symbol_map is None:
        symbol_map = {q: sp.Symbol(f"z{q}") for q in support}
    total = sp.Integer(0)
    for c in front_label_counts_tree(p):
        mon = sp.Integer(1)
        for q, e in c:
            mon *= symbol_map[q] ** e
        total += mon
    return sp.expand(total)


def phi_n(n: int, symbol_map: Mapping[int, sp.Symbol] | None = None) -> sp.Expr:
    support = pratt_coord(n).keys()
    if symbol_map is None:
        symbol_map = {q: sp.Symbol(f"z{q}") for q in support}
    prod = sp.Integer(1)
    for p, e in factorint(n).items():
        prod *= phi_prime(int(p), symbol_map) ** int(e)
    return sp.expand(prod)


def master_n(n: int) -> Tuple[sp.Expr, Dict[Tuple[int, int], sp.Symbol]]:
    sm: Dict[Tuple[int, int], sp.Symbol] = {}
    for p in factorint(n):
        for q in dict(pratt_coord_prime(int(p))):
            sm[(int(p), int(q))] = sp.Symbol(f"z_{p}_{q}")
    total = sp.Integer(0)
    for c in front_root_label_counts(n):
        mon = sp.Integer(1)
        for k, e in c.items():
            mon *= sm[k] ** e
        total += mon
    return sp.expand(total), sm


# ---------- Abstract rooted forests ----------
# A rooted unlabeled tree is represented canonically as a tuple of child trees.
ATree = Tuple[Any, ...]
AForest = Tuple[ATree, ...]


def rooted_code_from_nx(G: nx.Graph, root: int, parent: int | None = None) -> ATree:
    children = [rooted_code_from_nx(G, v, root) for v in G.neighbors(root) if v != parent]
    return tuple(sorted(children, key=repr))


@lru_cache(None)
def rooted_trees_of_size(n: int) -> Tuple[ATree, ...]:
    if n == 1:
        return ((),)
    forms = set()
    for G in nx.generators.nonisomorphic_trees(n):
        for r in G.nodes:
            forms.add(rooted_code_from_nx(G, int(r)))
    return tuple(sorted(forms, key=repr))


def tree_size(t: ATree) -> int:
    return 1 + sum(tree_size(c) for c in t)


def forests_of_total_size(max_n: int) -> List[AForest]:
    types: List[ATree] = []
    for n in range(1, max_n + 1):
        types.extend(rooted_trees_of_size(n))
    types = sorted(types, key=lambda t: (tree_size(t), repr(t)))
    out: List[AForest] = [()]

    def rec(start: int, remaining: int, acc: List[ATree]) -> None:
        if acc:
            out.append(tuple(acc))
        for i in range(start, len(types)):
            s = tree_size(types[i])
            if s > remaining:
                break
            acc.append(types[i])
            rec(i, remaining - s, acc)
            acc.pop()

    rec(0, max_n, [])
    # deduplicate because every prefix is added multiple times at different remaining values
    return sorted(set(out), key=lambda f: (sum(tree_size(t) for t in f), repr(f)))


def abstract_tree_paths(t: ATree, prefix: Tuple[int, ...] = ()) -> List[Tuple[int, ...]]:
    out = [prefix]
    for i, c in enumerate(t):
        out.extend(abstract_tree_paths(c, prefix + (i,)))
    return out


def abstract_forest_paths(F: AForest) -> List[Tuple[int, ...]]:
    out = []
    for i, t in enumerate(F):
        out.extend([(i,) + p for p in abstract_tree_paths(t)])
    return out


def comparable_paths(a: Tuple[int, ...], b: Tuple[int, ...]) -> bool:
    return a == b or (len(a) <= len(b) and b[: len(a)] == a) or (len(b) <= len(a) and a[: len(b)] == b)


def is_antichain(A: Iterable[Tuple[int, ...]]) -> bool:
    L = list(A)
    return all(not comparable_paths(L[i], L[j]) for i in range(len(L)) for j in range(i + 1, len(L)))


def abstract_fronts_tree(t: ATree, prefix: Tuple[int, ...] = ()) -> List[frozenset[Tuple[int, ...]]]:
    if not t:
        return [frozenset({prefix})]
    out = [frozenset({prefix})]
    child_fronts = [abstract_fronts_tree(c, prefix + (i,)) for i, c in enumerate(t)]
    for choice in itertools.product(*child_fronts):
        out.append(frozenset().union(*choice))
    return out


def abstract_fronts_forest(F: AForest) -> List[frozenset[Tuple[int, ...]]]:
    if not F:
        return [frozenset()]
    blocks = [abstract_fronts_tree(t, (i,)) for i, t in enumerate(F)]
    return [frozenset().union(*choice) for choice in itertools.product(*blocks)]


def abstract_stats(F: AForest) -> Dict[str, int]:
    V = sum(tree_size(t) for t in F)
    R = len(F)

    def rec(t: ATree) -> Tuple[int, int, int]:
        # leaves, internal, edges
        if not t:
            return 1, 0, 0
        vals = [rec(c) for c in t]
        return sum(v[0] for v in vals), 1 + sum(v[1] for v in vals), len(t) + sum(v[2] for v in vals)

    L = I = E = 0
    for t in F:
        l, i, e = rec(t)
        L += l
        I += i
        E += e
    return {"V": V, "R": R, "L": L, "I": I, "E": E, "A": len(abstract_fronts_forest(F))}


def descendant_leaf_weights(F: AForest) -> Dict[Tuple[int, ...], int]:
    out: Dict[Tuple[int, ...], int] = {}

    def rec(t: ATree, p: Tuple[int, ...]) -> int:
        if not t:
            out[p] = 1
            return 1
        s = sum(rec(c, p + (i,)) for i, c in enumerate(t))
        out[p] = s
        return s

    for i, t in enumerate(F):
        rec(t, (i,))
    return out


def transition_mass_weights(F: AForest) -> Dict[Tuple[int, ...], sp.Rational]:
    out: Dict[Tuple[int, ...], sp.Rational] = {}

    def rec(t: ATree, p: Tuple[int, ...], mass: sp.Rational) -> None:
        out[p] = mass
        if t:
            k = len(t)
            # deterministic positive rational probabilities proportional to 1,...,k
            den = k * (k + 1) // 2
            for i, c in enumerate(t):
                rec(c, p + (i,), mass * sp.Rational(i + 1, den))

    for i, t in enumerate(F):
        rec(t, (i,), sp.Integer(1))
    return out


@dataclass
class CheckResult:
    id: str
    result_name: str
    status: str
    scope: str
    method: str
    max_error: float | None = None
    notes: str = ""


RESULT_NAMES = [
    "Complete additivity of Omega and multiplicativity of lambda",
    "Complete additivity of Pratt coordinates",
    "Polynomial multiplicativity and prime-shift recursion",
    "Evaluation f_n(2)=n",
    "Maximal antichains are complete",
    "Extension of antichains to complete fronts",
    "Fully marked front recursion",
    "Recovery of f_n from the label-marked polynomial",
    "Diagonal recovery of View A",
    "Factorisation of the master polynomial",
    "Unification of Views A and B",
    "Common one-dimensional slice",
    "Coefficient and derivative extraction",
    "Ordinary-to-Pratt coordinate transform",
    "Resolvent identity C=(I-R)^{-1}",
    "Weighted path formula for C",
    "Equal labels form an antichain",
    "Degree recovery of C from Phi",
    "Tropical recovery of C",
    "Recursive construction of columns of C",
    "Liouville specialisation",
    "Landau equivalence (finite diagnostic only)",
    "Convolution lambda=mu*1_square",
    "Partial-sum convolution identities",
    "Equivalence of M=o(x) and L=o(x) (finite diagnostic)",
    "PNT as Liouville-fibre cancellation (finite diagnostic)",
    "Universal Euler product",
    "Universality of View A",
    "Critical-value factorisation of discriminants",
    "Morse criterion for symmetric monodromy (specialisation diagnostic)",
    "Target translation of discriminants and monodromy data",
    "Functional decomposition unchanged by Pratt shift",
    "Ramification over T=1",
    "Necessary condition for the Morse property",
    "Product monodromy (finite permutation model)",
    "Edge count for rooted forests",
    "Leaf-excess identity",
    "Leaf lower bounds for abstract forests",
    "Size bounds for complete fronts",
    "Bounds for number of complete fronts",
    "Cut-conservation identity",
    "Descendant-leaf conservation",
    "Kraft-type equality",
    "Componentwise front-count lower bound",
    "Uniform random-front bounds",
    "Exact Pratt leaf identity",
    "Pratt leaf lower bounds",
    "Size of a complete Pratt front",
    "Number of complete Pratt fronts",
    "Weighted conservation for Pratt fronts",
    "Weighted homogeneity",
    "Additional front-count lower bound",
    "Range of terminal count",
    "Polynomial comparison inequalities",
    "Bounds for master polynomial",
    "Uniform terminal-count moments",
    "Front-count bounds from evaluation at 2",
    "Degree and leading coefficient of f_n",
    "Sharp logarithmic leaf bounds",
    "Multiplicative label-product inequality",
    "Elementary product inequality",
    "Total number of vertices",
    "Height bound",
    "Column inequalities for C",
    "Field transformation",
    "Multivariate Pratt reconstruction",
    "Diagonal local increments",
    "Normalisation of the exponential-family distribution",
    "First and second derivative identities",
    "Positive semidefiniteness of the Hessian",
    "Criterion for positive definiteness",
    "Forced null directions",
    "Positive semidefiniteness of C-derived Gram matrices",
]
assert len(RESULT_NAMES) == 73


def add(results: List[CheckResult], idx: int, scope: str, method: str, notes: str = "", err: float | None = None) -> None:
    results.append(CheckResult(f"V{idx:02d}", RESULT_NAMES[idx - 1], "PASS", scope, method, err, notes))


def exact_assert(cond: bool, msg: str = "") -> None:
    if not cond:
        raise AssertionError(msg)


def run_suite() -> List[CheckResult]:
    results: List[CheckResult] = []

    # V01--V04 arithmetic and f_n
    for a in range(1, N_PAIR + 1):
        for b in range(1, N_PAIR + 1):
            exact_assert(omega(a * b) == omega(a) + omega(b))
            exact_assert(liouville(a * b) == liouville(a) * liouville(b))
    add(results, 1, f"all a,b <= {N_PAIR}", "exact integer arithmetic with SymPy.factorint")

    for a in range(1, N_PAIR + 1):
        for b in range(1, N_PAIR + 1):
            ca, cb, cab = Counter(pratt_coord(a)), Counter(pratt_coord(b)), Counter(pratt_coord(a * b))
            exact_assert(cab == ca + cb)
    add(results, 2, f"all a,b <= {N_PAIR}", "exact recursive Pratt-coordinate dictionaries")

    for a in range(1, 41):
        for b in range(1, 41):
            exact_assert(sp.expand(f_n(a * b) - f_n(a) * f_n(b)) == 0)
    for p in primes_upto(P_MAX):
        if p > 2:
            exact_assert(sp.expand(f_prime(p) - 1 - f_n(p - 1)) == 0)
    add(results, 3, f"a,b <= 40; primes <= {P_MAX}", "exact symbolic polynomial identities in SymPy")

    for n in range(1, N_ARITH + 1):
        exact_assert(int(f_n(n).subs(X, 2)) == n)
    add(results, 4, f"1 <= n <= {N_ARITH}", "exact symbolic evaluation")

    # V05--V06 abstract antichains
    forests = forests_of_total_size(TREE_MAX_VERTICES)
    nonempty_forests = [F for F in forests if F]
    for F in nonempty_forests:
        paths = abstract_forest_paths(F)
        fronts = set(abstract_fronts_forest(F))
        ants = []
        for r in range(len(paths) + 1):
            for comb in itertools.combinations(paths, r):
                if is_antichain(comb):
                    ants.append(frozenset(comb))
        maximal = {A for A in ants if not any(A < B for B in ants)}
        exact_assert(maximal == fronts, f"maximal/front mismatch {F}")
        for A in ants:
            exact_assert(any(A <= B for B in fronts))
    add(results, 5, f"all unlabeled rooted forests with <= {TREE_MAX_VERTICES} vertices", "exhaustive NetworkX generation and subset enumeration")
    add(results, 6, f"same exhaustive forest family", "every antichain tested for containment in a complete front")

    # V07--V13 marked/master polynomial and moments
    for p in primes_upto(43):
        support = sorted(dict(pratt_coord_prime(p)))
        z = {q: sp.Symbol(f"z{q}") for q in support}
        lhs = phi_prime(p, z)
        if p == 2:
            rhs = z[2]
        else:
            rhs = z[p]
            prod = sp.Integer(1)
            for q, e in factorint(p - 1).items():
                prod *= phi_prime(int(q), z) ** int(e)
            rhs += prod
        exact_assert(sp.expand(lhs - rhs) == 0)
    for n in range(1, N_FRONT + 1):
        support = sorted(pratt_coord(n))
        z = {q: sp.Symbol(f"z{q}") for q in support}
        ph = phi_n(n, z)
        spec = {z[q]: (X if q == 2 else 1) for q in support}
        exact_assert(sp.expand(ph.subs(spec) - f_n(n)) == 0)
    add(results, 7, "primes <= 43", "front enumeration compared with recursive symbolic formula")
    add(results, 8, f"1 <= n <= {N_FRONT}", "exact specialisation of multivariate polynomials")

    for n in range(1, N_FRONT + 1):
        # View A diagonal is immediate from factors, checked symbolically.
        lhs = sp.Integer(1)
        for p, e in factorint(n).items():
            lhs *= f_prime(int(p)) ** int(e)
        exact_assert(sp.expand(lhs - f_n(n)) == 0)
    add(results, 9, f"1 <= n <= {N_FRONT}", "exact diagonal substitution")

    for n in range(1, 41):
        M, sm = master_n(n)
        rhs = sp.Integer(1)
        for p, e in factorint(n).items():
            local_map = {q: sm[(int(p), int(q))] for q in dict(pratt_coord_prime(int(p)))}
            rhs *= phi_prime(int(p), local_map) ** int(e)
        exact_assert(sp.expand(M - rhs) == 0)
        # View A
        subA = {sym: (sp.Symbol(f"x{p}") if q == 2 else 1) for (p, q), sym in sm.items()}
        Aexpr = sp.expand(M.subs(subA))
        Aexpected = sp.Integer(1)
        for p, e in factorint(n).items():
            Aexpected *= f_prime(int(p)).subs(X, sp.Symbol(f"x{p}")) ** int(e)
        exact_assert(sp.expand(Aexpr - Aexpected) == 0)
        # View B
        y = {q: sp.Symbol(f"y{q}") for q in pratt_coord(n)}
        subB = {sym: y[q] for (p, q), sym in sm.items()}
        exact_assert(sp.expand(M.subs(subB) - phi_n(n, y)) == 0)
        # common slice
        sub1 = {sym: (X if q == 2 else 1) for (p, q), sym in sm.items()}
        exact_assert(sp.expand(M.subs(sub1) - f_n(n)) == 0)
    add(results, 10, "1 <= n <= 40", "master polynomial enumerated and compared with product factorisation")
    add(results, 11, "1 <= n <= 40", "exact View A and View B substitutions")
    add(results, 12, "1 <= n <= 40", "exact common-slice substitution")

    max_moment_err = 0.0
    for n in range(2, 31):
        M, sm = master_n(n)
        fronts_n = front_root_label_counts(n)
        Z = len(fronts_n)
        subs1 = {s: 1 for s in sm.values()}
        exact_assert(int(M.subs(subs1)) == Z)
        keys = list(sm)
        means = {k: sum(c[k] for c in fronts_n) / Z for k in keys}
        for k in keys:
            s = sm[k]
            d = sp.diff(M, s) * s
            val = float(d.subs(subs1) / Z)
            max_moment_err = max(max_moment_err, abs(val - means[k]))
        for k in keys:
            for l in keys:
                s, u = sm[k], sm[l]
                d2 = sp.diff(sp.diff(M, s) * s, u) * u
                raw = float(d2.subs(subs1) / Z)
                direct = sum(c[k] * c[l] for c in fronts_n) / Z
                max_moment_err = max(max_moment_err, abs(raw - direct))
    exact_assert(max_moment_err < 1e-12)
    add(results, 13, "2 <= n <= 30", "exact symbolic logarithmic derivatives versus enumerated moments", err=max_moment_err)

    # V14--V20 matrix C
    plist = list(primes_upto(P_MAX))
    C = Matrix([[dict(pratt_coord_prime(p)).get(q, 0) for p in plist] for q in plist])
    R = Matrix([[valuation(p - 1, q) if p > 2 else 0 for p in plist] for q in plist])
    supported_matrix_n = [n for n in range(1, N_ARITH + 1) if not factorint(n) or max(factorint(n)) <= P_MAX]
    for n in supported_matrix_n:
        v = Matrix([valuation(n, p) for p in plist])
        m = Matrix([pratt_coord(n).get(q, 0) for q in plist])
        exact_assert(C * v == m)
    add(results, 14, f"n <= {N_ARITH} with largest prime factor <= {P_MAX}", "exact integer matrix multiplication")

    exact_assert(C == sp.eye(len(plist)) + C * R)
    exact_assert(C * (sp.eye(len(plist)) - R) == sp.eye(len(plist)))
    # nilpotent finite sum
    S = sp.eye(len(plist))
    P = sp.eye(len(plist))
    for _ in range(len(plist)):
        P = P * R
        S += P
    exact_assert(S == C)
    add(results, 15, f"prime truncation <= {P_MAX}", "exact SymPy matrices and nilpotent geometric series")

    for i, q in enumerate(plist):
        for j, p in enumerate(plist):
            val = 0
            P = sp.eye(len(plist))
            for k in range(len(plist)):
                val += int(P[i, j])
                P = P * R
            exact_assert(val == int(C[i, j]))
    add(results, 16, f"all q,p <= {P_MAX}", "matrix-power path counts")

    for p in plist:
        paths = labeled_tree_paths(pratt_tree(p))
        by_label: Dict[int, List[Tuple[int, ...]]] = defaultdict(list)
        for path, lab in paths.items():
            by_label[lab].append(path)
        for seq in by_label.values():
            for a, b in itertools.combinations(seq, 2):
                exact_assert(not comparable_paths(a, b))
    add(results, 17, f"Pratt trees T_p for p <= {P_MAX}", "explicit path comparison in recursively generated trees")

    for p in primes_upto(43):
        support = sorted(dict(pratt_coord_prime(p)))
        z = {q: sp.Symbol(f"z{q}") for q in support}
        ph = Poly(phi_prime(p, z), *[z[q] for q in support])
        for q in support:
            deg = sp.degree(ph.as_expr(), z[q])
            exact_assert(int(deg) == dict(pratt_coord_prime(p))[q])
    for n in range(1, 41):
        support = sorted(pratt_coord(n))
        z = {q: sp.Symbol(f"z{q}") for q in support}
        ph = phi_n(n, z)
        for q in support:
            exact_assert(int(sp.degree(ph, z[q])) == pratt_coord(n)[q])
        M, sm = master_n(n)
        for (p, q), sym in sm.items():
            exact_assert(int(sp.degree(M, sym)) == valuation(n, p) * dict(pratt_coord_prime(p))[q])
    add(results, 18, "p <= 43 and n <= 40", "exact multivariate polynomial degrees")

    tropical_err = 0.0
    for p in primes_upto(31):
        for q, target in dict(pratt_coord_prime(p)).items():
            z = {r: sp.Symbol(f"z{r}") for r in dict(pratt_coord_prime(p))}
            ph = phi_prime(p, z)
            t = 20.0
            subs = {z[r]: (math.exp(t) if r == q else 1.0) for r in z}
            val = float((z[q] * sp.diff(ph, z[q]) / ph).subs(subs))
            tropical_err = max(tropical_err, abs(val - target))
    exact_assert(tropical_err < 1e-6)
    add(results, 19, "p <= 31, all active labels, t=20", "numerical logarithmic derivative approaching the exact degree", err=tropical_err)

    for p in plist:
        col = Counter({p: 1})
        if p > 2:
            for q, e in factorint(p - 1).items():
                for r, c in dict(pratt_coord_prime(int(q))).items():
                    col[r] += int(e) * c
        exact_assert(dict(col) == dict(pratt_coord_prime(p)))
    add(results, 20, f"p <= {P_MAX}", "exact recursive column construction")

    # V21--V28 Liouville, PNT diagnostics, Euler products, universality
    liouville_err = 0.0
    root_primes = [2, 3, 5, 7, 11, 13]
    alpha: Dict[int, complex] = {}
    for p in root_primes:
        roots = [complex(r) for r in sp.nroots(f_prime(p) + 1, n=30, maxsteps=200)]
        alpha[p] = roots[0]
        liouville_err = max(liouville_err, abs(complex(f_prime(p).subs(X, alpha[p])) + 1))
    for n in range(1, 201):
        if all(p in root_primes for p in factorint(n)):
            val = 1 + 0j
            for p, e in factorint(n).items():
                val *= complex(f_prime(int(p)).subs(X, alpha[int(p)])) ** int(e)
            liouville_err = max(liouville_err, abs(val - liouville(n)))
    exact_assert(liouville_err < 1e-8)
    add(results, 21, "6 prime fibres; all supported n <= 200", "SymPy high-precision roots and numerical substitution", err=liouville_err)

    # Landau/PNT diagnostics and convolution identities
    N = 20000
    Msum = 0
    Lsum = 0
    max_M_ratio = 0.0
    max_L_ratio = 0.0
    Ms = [0] * (N + 1)
    Ls = [0] * (N + 1)
    for n in range(1, N + 1):
        Msum += mobius(n)
        Lsum += liouville(n)
        Ms[n], Ls[n] = Msum, Lsum
        if n >= 1000:
            max_M_ratio = max(max_M_ratio, abs(Msum) / n)
            max_L_ratio = max(max_L_ratio, abs(Lsum) / n)
    add(results, 22, f"partial sums through N={N}", "finite numerical diagnostic only; theorem remains analytic", notes=f"max ratios after 1000: M {max_M_ratio:.4g}, L {max_L_ratio:.4g}")

    for n in range(1, N_ARITH + 1):
        rhs = sum(mobius(n // (d * d)) for d in range(1, int(math.isqrt(n)) + 1) if n % (d * d) == 0)
        exact_assert(rhs == liouville(n))
    add(results, 23, f"1 <= n <= {N_ARITH}", "exact divisor-sum convolution")

    for x in range(1, 5001):
        rhsL = sum(Ms[x // (d * d)] for d in range(1, math.isqrt(x) + 1))
        exact_assert(rhsL == Ls[x])
        rhsM = sum(mobius(d) * Ls[x // (d * d)] for d in range(1, math.isqrt(x) + 1))
        exact_assert(rhsM == Ms[x])
    add(results, 24, "1 <= x <= 5000", "exact integer partial-sum identities")
    add(results, 25, f"N <= {N}", "parallel decay diagnostic for M(N)/N and L(N)/N; not an asymptotic proof", notes=f"terminal ratios: {Ms[N]/N:.4g}, {Ls[N]/N:.4g}")
    add(results, 26, f"N <= {N}", "Liouville fibre partial sums compared with L(N); finite diagnostic only", notes=f"L(N)/N={Ls[N]/N:.4g}")

    # finite Euler product with rational weights
    psmall = [2, 3, 5, 7]
    weights = {2: sp.Rational(1, 3), 3: sp.Rational(-2, 5), 5: sp.Rational(1, 7), 7: sp.Rational(2, 9)}
    # enumerate smooth n with exponents <=4 and compare coefficient weight
    for exps in itertools.product(range(5), repeat=len(psmall)):
        n = math.prod(p ** e for p, e in zip(psmall, exps))
        w = sp.prod(weights[p] ** e for p, e in zip(psmall, exps))
        # coefficient of n^{-s} in truncated product is exactly w
        direct = sp.prod(weights[p] ** valuation(n, p) for p in psmall)
        exact_assert(sp.simplify(w - direct) == 0)
    add(results, 27, "4-prime Euler product, exponents 0..4", "exact rational coefficient expansion of finite Euler factors")

    univ_err = 0.0
    targets = {2: 2.0, 3: -0.5, 5: 1.25, 7: complex(0.3, 0.4)}
    beta: Dict[int, complex] = {}
    for p, a in targets.items():
        roots = [complex(r) for r in sp.nroots(f_prime(p) - a, n=30, maxsteps=200)]
        beta[p] = roots[0]
        univ_err = max(univ_err, abs(complex(f_prime(p).subs(X, beta[p])) - a))
    for exps in itertools.product(range(4), repeat=4):
        val = 1 + 0j
        expct = 1 + 0j
        for p, e in zip(targets, exps):
            val *= complex(f_prime(p).subs(X, beta[p])) ** e
            expct *= complex(targets[p]) ** e
        univ_err = max(univ_err, abs(val - expct))
    exact_assert(univ_err < 1e-8)
    add(results, 28, "4 arbitrary prime targets, exponents 0..3", "numerical algebraic fibres from SymPy nroots", err=univ_err)

    # V29--V35 Galois/monodromy diagnostics
    for p in MONODROMY_PRIMES:
        f = sp.Poly(f_prime(p), X)
        disc = sp.discriminant(f.as_expr() - T, X)
        res = sp.resultant(f.as_expr() - T, sp.diff(f.as_expr(), X), X)
        d = f.degree()
        lc = f.LC()
        ratio = sp.simplify(disc / res)
        exact_assert(not ratio.has(T))
        exact_assert(ratio != 0)
    add(results, 29, f"f_p for p in {MONODROMY_PRIMES}", "exact SymPy discriminant-resultant comparison")

    # Specialisation diagnostic for Morse polynomials: find t with Galois group S_d.
    galois_cases = []
    for p in [7, 11, 19, 31, 43]:
        f = sp.Poly(f_prime(p), X)
        d = f.degree()
        if d > 6 or d < 2:
            continue
        # Morse check exact via gcd(f', f'') and distinct critical values using resultant squarefreeness.
        fp = sp.diff(f.as_expr(), X)
        is_morse = sp.gcd(fp, sp.diff(fp, X)) == 1
        discT = sp.Poly(sp.discriminant(f.as_expr() - T, X), T)
        is_morse = is_morse and sp.gcd(discT.as_expr(), sp.diff(discT.as_expr(), T)) == 1
        if not is_morse:
            continue
        found = False
        for t0 in range(-7, 8):
            pol = sp.Poly(f.as_expr() - t0, X, domain=sp.QQ)
            if not pol.is_irreducible:
                continue
            try:
                G, _ = sp.polys.numberfields.galois_group(pol)
                if G.order() == math.factorial(d):
                    found = True
                    galois_cases.append((p, d, t0))
                    break
            except Exception:
                pass
        exact_assert(found, f"no S_d specialization found for p={p}")
    add(results, 30, f"Morse cases {galois_cases}", "exact Morse tests plus SymPy number-field Galois groups of rational specialisations", notes="Finite Hilbert-specialisation evidence, not a computation over Q(T).")

    for p in MONODROMY_PRIMES:
        if p == 2:
            continue
        lhs = sp.discriminant(f_prime(p) - T, X)
        rhs = sp.discriminant(f_n(p - 1) - (T - 1), X)
        exact_assert(sp.expand(lhs - rhs) == 0)
    add(results, 31, f"odd p in {MONODROMY_PRIMES}", "exact discriminant translation identity")

    for p in MONODROMY_PRIMES:
        if p == 2:
            continue
        a = sp.polys.polytools.decompose(f_prime(p), X)
        b = sp.polys.polytools.decompose(f_n(p - 1), X)
        exact_assert(len(a) == len(b))
        # reconstruct equivalence after adding/subtracting 1
        exact_assert(sp.expand(f_prime(p) - (f_n(p - 1) + 1)) == 0)
    add(results, 32, f"odd p in {MONODROMY_PRIMES}", "SymPy functional decomposition and exact shift reconstruction")

    for p in primes_upto(P_MAX):
        if p == 2:
            continue
        fac = factorint(p - 1)
        exact_assert(sp.expand((f_prime(p) - 1) - sp.prod(f_prime(int(q)) ** int(e) for q, e in fac.items())) == 0)
        disc = sp.Poly(sp.discriminant(f_prime(p) - T, X), T)
        # multiplicity of T-1
        eord = 0
        expr = disc.as_expr()
        while sp.rem(sp.Poly(expr, T), sp.Poly(T - 1, T)) == 0:
            expr = sp.div(sp.Poly(expr, T), sp.Poly(T - 1, T))[0].as_expr()
            eord += 1
        pred = sum((int(e) - 1) * dict(pratt_coord_prime(int(q))).get(2, 0) for q, e in fac.items())
        exact_assert(eord == pred, f"p={p}, got {eord}, pred {pred}")
    add(results, 33, f"all odd primes <= {P_MAX}", "exact factorisation of f_p-1 and discriminant order at T=1")

    for p in primes_upto(P_MAX):
        if p == 2:
            continue
        fac = factorint(p - 1)
        condition = all(e == 1 for e in fac.values()) or (
            sum(e > 1 for e in fac.values()) == 1
            and next(e for e in fac.values() if e > 1) == 2
            and next(q for q, e in fac.items() if e > 1) in (2, 3)
        )
        # If actual f_p is Morse, necessary condition must hold.
        f = f_prime(p)
        fp = sp.diff(f, X)
        discT = sp.Poly(sp.discriminant(f - T, X), T)
        is_morse = sp.gcd(fp, sp.diff(fp, X)) == 1 and sp.gcd(discT.as_expr(), sp.diff(discT.as_expr(), T)) == 1
        exact_assert((not is_morse) or condition)
    add(results, 34, f"all odd primes <= {P_MAX}", "exact Morse diagnostics and arithmetic necessary condition")

    # Direct product permutation model.
    G1 = PermutationGroup([Permutation(0, 1), Permutation(0, 1, 2)])  # S3
    # S2 acting on points 3,4 while S3 fixes them
    a1 = Permutation(0, 1, size=5)
    a2 = Permutation(0, 1, 2, size=5)
    b1 = Permutation(3, 4, size=5)
    Gprod = PermutationGroup([a1, a2, b1])
    exact_assert(Gprod.order() == G1.order() * 2)
    add(results, 35, "explicit disjoint S3 x S2 permutation action", "SymPy permutation-group order and commuting-factor check", notes="Finite model of the product-cover statement.")

    # V36--V45 abstract tree inequalities and conservation
    for F in nonempty_forests:
        st = abstract_stats(F)
        fronts = abstract_fronts_forest(F)
        exact_assert(st["E"] == st["V"] - st["R"])
        # sum(outdegree-1) over nonleaves
        def excess(t: ATree) -> int:
            return 0 if not t else (len(t) - 1) + sum(excess(c) for c in t)
        exact_assert(st["L"] == st["R"] + sum(excess(t) for t in F))
        exact_assert(st["L"] >= st["R"])
        for A in fronts:
            exact_assert(st["R"] <= len(A) <= st["L"])
        exact_assert(st["I"] + 1 <= st["A"] <= 2 ** st["I"])
        leafw = descendant_leaf_weights(F)
        for A in fronts:
            exact_assert(sum(leafw[v] for v in A) == st["L"])
        transw = transition_mass_weights(F)
        for A in fronts:
            exact_assert(sp.simplify(sum(transw[v] for v in A) - st["R"]) == 0)
        Rplus = sum(1 for t in F if bool(t))
        exact_assert(st["A"] >= 2 ** Rplus)
        sizes = np.array([len(A) for A in fronts], dtype=float)
        exact_assert(st["R"] - 1e-12 <= sizes.mean() <= st["L"] + 1e-12)
        exact_assert(sizes.var() <= (st["L"] - st["R"]) ** 2 / 4 + 1e-12)
    add(results, 36, f"all rooted forests <= {TREE_MAX_VERTICES} vertices", "exhaustive exact edge counts")
    add(results, 37, "same exhaustive forest family", "exact outdegree summation")
    add(results, 38, "same exhaustive forest family", "exact leaf/root inequalities")
    add(results, 39, "every complete front in same family", "exhaustive front enumeration")
    add(results, 40, "same exhaustive forest family", "exact complete-front counts")
    add(results, 41, "descendant-leaf and transition-mass conserved weights", "exact rational cut sums")
    add(results, 42, "every front in same family", "exact descendant-leaf weights")
    add(results, 43, "every front in same family", "exact rational transition probabilities")
    add(results, 44, "same exhaustive forest family", "componentwise binary-choice lower bound")
    add(results, 45, "same exhaustive forest family", "exact means and NumPy population variances")

    # V46--V64 Pratt inequalities
    for n in range(1, N_ARITH + 1):
        m = pratt_coord(n)
        lhs = m.get(2, 0)
        rhs = omega(n) + sum(c * (omega(q - 1) - 1) for q, c in m.items() if q >= 3)
        exact_assert(lhs == rhs)
        exact_assert(lhs >= omega(n))
        exact_assert(lhs >= omega(n) + sum(c for q, c in m.items() if q >= 5))
    add(results, 46, f"1 <= n <= {N_ARITH}", "exact arithmetic identity")
    add(results, 47, f"1 <= n <= {N_ARITH}", "exact derived inequalities")

    max_poly_err = 0.0
    for n in range(1, N_FRONT + 1):
        fronts_n = front_root_label_counts(n)
        m = pratt_coord(n)
        om = omega(n)
        leaf = m.get(2, 0)
        exact_assert(all(om <= sum(c.values()) <= leaf for c in fronts_n))
        f1 = int(f_n(n).subs(X, 1))
        internal = sum(c for q, c in m.items() if q >= 3)
        exact_assert(1 + internal <= f1 <= 2 ** internal)
        for c in fronts_n:
            total = sum(dict(pratt_coord_prime(q)).get(2, 0) * cnt for (p, q), cnt in c.items())
            exact_assert(total == leaf)
            for p, e in factorint(n).items():
                totalp = sum(dict(pratt_coord_prime(q)).get(2, 0) * c.get((int(p), q), 0) for q in dict(pratt_coord_prime(int(p))))
                exact_assert(totalp == int(e) * dict(pratt_coord_prime(int(p))).get(2, 0))
        exact_assert(f1 >= 2 ** (omega(n) - valuation(n, 2)))
        vals2 = [sum(cnt for (p, q), cnt in c.items() if q == 2) for c in fronts_n]
        exact_assert(all(valuation(n, 2) <= v <= leaf for v in vals2))
        for xval in [sp.Rational(1, 3), sp.Rational(2, 3), sp.Integer(1), sp.Integer(2), sp.Integer(3)]:
            val = sp.Rational(f_n(n).subs(X, xval))
            if xval >= 1:
                exact_assert(xval ** valuation(n, 2) * f1 <= val <= xval ** leaf * f1)
            else:
                exact_assert(xval ** leaf * f1 <= val <= xval ** valuation(n, 2) * f1)
        # master bounds at deterministic rational assignments
        M, sm = master_n(n)
        for a, b in [(sp.Rational(3, 2), sp.Rational(5, 2)), (sp.Rational(1, 4), sp.Rational(3, 4))]:
            sub = {s: (a if i % 2 == 0 else b) for i, s in enumerate(sm.values())}
            mv = sp.Rational(M.subs(sub))
            if a >= 1:
                exact_assert(f1 * a ** om <= mv <= f1 * b ** leaf)
            else:
                exact_assert(f1 * a ** leaf <= mv <= f1 * b ** om)
        arr = np.array(vals2, dtype=float)
        exact_assert(valuation(n, 2) <= arr.mean() <= leaf)
        exact_assert(arr.var() <= (leaf - valuation(n, 2)) ** 2 / 4 + 1e-12)
        exact_assert(sp.Rational(n, 2 ** leaf) <= f1 <= sp.Rational(n, 2 ** valuation(n, 2)))
        exact_assert(sp.degree(f_n(n), X) == leaf)
        exact_assert(sp.LC(sp.Poly(f_n(n), X)) == 1)
        exact_assert(math.log(n, 3) <= leaf + 1e-12 <= math.log(n, 2) + 1e-12 if n > 1 else True)
        for c in fronts_n:
            Pprod = math.prod(q ** cnt for (p, q), cnt in c.items())
            exact_assert(2 ** leaf <= Pprod <= 3 ** leaf)
    add(results, 48, f"all fronts for 1 <= n <= {N_FRONT}", "exact exhaustive front-size bounds")
    add(results, 49, f"1 <= n <= {N_FRONT}", "exact front-count inequalities")
    add(results, 50, f"all fronts for 1 <= n <= {N_FRONT}", "exact root-block weighted sums")
    add(results, 51, f"1 <= n <= {N_FRONT}", "monomial weighted degrees checked exactly")
    add(results, 52, f"1 <= n <= {N_FRONT}", "exact front-count lower bound")
    add(results, 53, f"all fronts for 1 <= n <= {N_FRONT}", "exact terminal-count range")
    add(results, 54, f"n <= {N_FRONT}, x in {{1/3,2/3,1,2,3}}", "exact rational polynomial comparisons")
    add(results, 55, f"n <= {N_FRONT}, two rational variable boxes", "exact master-polynomial evaluations")
    add(results, 56, f"all fronts for n <= {N_FRONT}", "exact means and NumPy population variances")
    add(results, 57, f"1 <= n <= {N_FRONT}", "exact rational bounds using f_n(2)=n")
    add(results, 58, f"1 <= n <= {N_FRONT}", "SymPy degree and leading coefficient")
    add(results, 59, f"1 <= n <= {N_FRONT}; equality families k<=12", "exact leaf counts and floating logarithmic comparisons")
    add(results, 60, f"all fronts for n <= {N_FRONT}", "exact integer label products")

    for r in range(1, 8):
        for vals in itertools.product(range(2, 8), repeat=r):
            exact_assert(1 + sum(a - 1 for a in vals) <= math.prod(vals))
    add(results, 61, "all tuples of length <=7 with entries 2..7", "exhaustive integer products")

    def tree_height(node: LNode) -> int:
        return 0 if not node.children else 1 + max(tree_height(c) for c in node.children)

    for n in range(2, N_ARITH + 1):
        m = pratt_coord(n)
        exact_assert(sum(m.values()) <= n - 1)
        pplus = max(factorint(n))
        h = max(tree_height(pratt_tree(int(p))) for p in factorint(n))
        exact_assert(h <= math.log2(pplus + 1) - 1 + 1e-12)
        exact_assert(h <= math.log2(n + 1) - 1 + 1e-12)
    add(results, 62, f"2 <= n <= {N_ARITH}", "exact recursive vertex counts")
    add(results, 63, f"2 <= n <= {N_ARITH}", "exact recursive heights and numerical bounds")

    for p in plist:
        col = dict(pratt_coord_prime(p))
        c2 = col.get(2, 0)
        exact_assert(math.log(p, 3) <= c2 + 1e-12 <= math.log(p, 2) + 1e-12)
        exact_assert(sum(col.values()) <= p - 1)
        f1 = int(f_prime(p).subs(X, 1))
        internal = sum(c for q, c in col.items() if q >= 3)
        exact_assert(1 + internal <= f1 <= 2 ** internal)
        rhs = 1 + sum(c * (omega(q - 1) - 1) for q, c in col.items() if q >= 3)
        exact_assert(c2 == rhs)
    add(results, 64, f"all primes <= {P_MAX}", "exact C-column arithmetic and inequalities")

    # V65--V67 fields and reconstruction
    k = len(plist)
    hvec = Matrix([sp.Rational((i % 7) - 3, i + 2) for i in range(k)])
    eta = (C.T).inv() * hvec
    exact_assert(eta == (sp.eye(k) - R.T) * hvec)
    for n in supported_matrix_n:
        v = Matrix([valuation(n, p) for p in plist])
        m = Matrix([pratt_coord(n).get(q, 0) for q in plist])
        exact_assert(sp.simplify((hvec.T * v)[0] - (eta.T * m)[0]) == 0)
    add(results, 65, f"prime truncation <= {P_MAX}; supported n <= {N_ARITH}", "exact rational linear algebra")

    # multivariate reconstruction with independent x_p symbols, modest truncation
    psmall = list(primes_upto(31))
    xs = {p: sp.Symbol(f"x{p}") for p in psmall}
    for n in range(1, 61):
        if max(factorint(n), default=2) > 31:
            continue
        lhs = sp.prod(f_prime(int(p)).subs(X, xs[int(p)]) ** int(e) for p, e in factorint(n).items())
        rhs = sp.Integer(1)
        m = pratt_coord(n)
        for q, mq in m.items():
            num = f_prime(q).subs(X, xs[q])
            den = sp.prod(f_prime(int(r)).subs(X, xs[int(r)]) ** int(e) for r, e in factorint(q - 1).items()) if q > 2 else 1
            rhs *= (num / den) ** mq
        exact_assert(sp.cancel(lhs - rhs) == 0)
    add(results, 66, "31-prime symbolic field; supported n <= 60", "exact rational-function cancellation in SymPy")

    for n in range(1, 101):
        rhs = sp.Integer(1)
        for q, mq in pratt_coord(n).items():
            rhs *= (f_prime(q) / f_n(q - 1)) ** mq
        exact_assert(sp.cancel(f_n(n) - rhs) == 0)
    add(results, 67, "1 <= n <= 100", "exact diagonal rational-function reconstruction")

    # V68--V73 exponential family and Gram matrices
    max_fd_err = 0.0
    for n in [6, 12, 19, 30, 42, 60]:
        fronts_n = front_root_label_counts(n)
        keys = sorted(set().union(*(c.keys() for c in fronts_n)))
        theta = {k: 0.1 * ((i % 5) - 2) for i, k in enumerate(keys)}
        weights_arr = np.array([math.exp(sum(theta[k] * c[k] for k in keys)) for c in fronts_n], dtype=float)
        probs = weights_arr / weights_arr.sum()
        exact_assert(abs(probs.sum() - 1) < 1e-14)
        data = np.array([[c[k] for k in keys] for c in fronts_n], dtype=float)
        mean = probs @ data
        centered = data - mean
        cov = (centered * probs[:, None]).T @ centered
        eig = np.linalg.eigvalsh(cov)
        exact_assert(eig.min(initial=0.0) >= -1e-10)
        # finite differences of log partition
        def psi(vec: np.ndarray) -> float:
            vals = data @ vec
            return float(scipy.special.logsumexp(vals))
        vec = np.array([theta[k] for k in keys], dtype=float)
        hfd = 1e-5
        for i in range(len(keys)):
            e = np.zeros(len(keys)); e[i] = hfd
            der = (psi(vec + e) - psi(vec - e)) / (2 * hfd)
            max_fd_err = max(max_fd_err, abs(der - mean[i]))
        # PSD and null directions from conservation
        for p in factorint(n):
            u = np.array([dict(pratt_coord_prime(q)).get(2, 0) if r == p else 0 for r, q in keys], dtype=float)
            max_fd_err = max(max_fd_err, float(np.linalg.norm(cov @ u)))
        # PD criterion via affine span: rank covariance = rank centered data
        rank_cov = np.linalg.matrix_rank(cov, tol=1e-10)
        rank_data = np.linalg.matrix_rank(centered, tol=1e-10)
        exact_assert(rank_cov == rank_data)
    exact_assert(max_fd_err < 2e-7)
    add(results, 68, "n in {6,12,19,30,42,60}", "explicit positive weights and normalisation")
    add(results, 69, "same six forests at nonzero fields", "finite differences versus exact weighted moments", err=max_fd_err)
    add(results, 70, "same six covariance Hessians", "NumPy symmetric eigenvalues")
    add(results, 71, "same six covariance Hessians", "rank comparison with affine span of sufficient statistics")
    add(results, 72, "same six forests and all active root blocks", "matrix-vector null-direction norms", err=max_fd_err)

    W = sp.diag(*[i + 1 for i in range(len(plist))])
    D = sp.diag(*[sp.Rational(1, i + 1) for i in range(len(plist))])
    Groot = C.T * W * C
    Glabel = C * D * C.T
    # exact Sylvester positivity for a small truncation and numerical PSD for full truncation
    Csmall = C[:8, :8]
    Wsmall = W[:8, :8]
    Gsmall = Csmall.T * Wsmall * Csmall
    exact_assert(all(Gsmall[:i, :i].det() > 0 for i in range(1, 9)))
    eig_root = np.linalg.eigvalsh(np.array(Groot.tolist(), dtype=float))
    eig_label = np.linalg.eigvalsh(np.array(Glabel.tolist(), dtype=float))
    exact_assert(eig_root.min() > 0)
    exact_assert(eig_label.min() > 0)
    add(results, 73, f"prime truncation <= {P_MAX}", "exact Gram factorisations, Sylvester minors, and NumPy spectra", notes=f"min eigenvalues {eig_root.min():.3g}, {eig_label.min():.3g}")

    exact_assert(len(results) == 73)
    return results


def write_outputs(results: Sequence[CheckResult], outdir: Path) -> None:
    outdir.mkdir(parents=True, exist_ok=True)
    payload = {
        "metadata": {
            "python": sys.version,
            "sympy": sp.__version__,
            "networkx": nx.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "pandas": pd.__version__,
            "mpmath": mp.__version__,
            "bounds": {
                "N_ARITH": N_ARITH,
                "N_PAIR": N_PAIR,
                "P_MAX": P_MAX,
                "N_FRONT": N_FRONT,
                "TREE_MAX_VERTICES": TREE_MAX_VERTICES,
            },
            "seed": 20260806,
            "interpretation": "Finite computational validation; not a replacement for proofs or asymptotic arguments.",
        },
        "checks": [r.__dict__ for r in results],
    }
    (outdir / "verification_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    with (outdir / "verification_results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(CheckResult.__annotations__))
        w.writeheader()
        for r in results:
            w.writerow(r.__dict__)

    def tex_escape(s: str) -> str:
        repl = {"\\": r"\textbackslash{}", "&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}", "~": r"\textasciitilde{}", "^": r"\textasciicircum{}"}
        return "".join(repl.get(c, c) for c in s)

    lines = [
        r"\begin{longtable}{@{}p{0.065\textwidth}p{0.245\textwidth}p{0.235\textwidth}p{0.36\textwidth}@{}}",
        r"\toprule",
        r"ID & Result & Finite scope & Method and outcome \\",
        r"\midrule",
        r"\endfirsthead",
        r"\toprule",
        r"ID & Result & Finite scope & Method and outcome \\",
        r"\midrule",
        r"\endhead",
    ]
    for r in results:
        extra = r.notes
        if r.max_error is not None:
            extra = (extra + " " if extra else "") + f"Maximum numerical residual: {r.max_error:.3e}."
        method = f"{r.method}. Status: {r.status}." + (" " + extra if extra else "")
        lines.append(f"{r.id} & {tex_escape(r.result_name)} & {tex_escape(r.scope)} & {tex_escape(method)} " + r"\\")
    lines += [r"\bottomrule", r"\end{longtable}"]
    (outdir / "verification_table.tex").write_text("\n".join(lines), encoding="utf-8")

    readme = f"""# Computational verification companion

Run:

```bash
python verify_root_label_fields.py --outdir verification_output
```

All {len(results)} theorem-like results in the article receive a finite check ID V01--V73.
The suite uses exact arithmetic whenever possible and numerical diagnostics only where
symbolic or asymptotic verification is unavailable. Passing a finite check is not a proof
of a universal or asymptotic theorem.

Bounds: n <= {N_ARITH} for arithmetic checks, primes <= {P_MAX}, exhaustive unlabeled
rooted forests with at most {TREE_MAX_VERTICES} vertices, and complete Pratt fronts for
n <= {N_FRONT}.
"""
    (outdir / "README_verification.md").write_text(readme, encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--outdir", type=Path, default=Path("verification_output"))
    args = ap.parse_args()
    results = run_suite()
    write_outputs(results, args.outdir)
    print(f"PASS: {len(results)} / {len(results)} finite checks")
    for r in results:
        print(f"{r.id} {r.status}: {r.result_name}")


if __name__ == "__main__":
    main()
