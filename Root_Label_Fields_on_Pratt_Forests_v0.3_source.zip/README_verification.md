# Computational verification companion

Run:

```bash
python verify_root_label_fields.py --outdir verification_output
```

All 73 theorem-like results in the article receive a finite check ID V01--V73.
The suite uses exact arithmetic whenever possible and numerical diagnostics only where
symbolic or asymptotic verification is unavailable. Passing a finite check is not a proof
of a universal or asymptotic theorem.

Bounds: n <= 500 for arithmetic checks, primes <= 127, exhaustive unlabeled
rooted forests with at most 7 vertices, and complete Pratt fronts for
n <= 60.
